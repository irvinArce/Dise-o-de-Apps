import React from "react";
import {View, Text, StyleSheet, TouchableOPacity} from "react-native";

const VerPedidos = () => {
    return(
        <View>
            <Text
             style = {{
                fontSize: 30,
                textAlign: "center",
                marginTop: "20%"
             }}   
            >
                Ver Pedidos
            </Text>
        </View>
    );
}

export default VerPedidos;