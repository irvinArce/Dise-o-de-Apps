import React from "react";
import {View, Text, StyleSheet, TouchableOPacity} from "react-native";

const EstadosScreen = () => {
    return(
        <View>
            <Text
             style = {{
                fontSize: 30,
                textAlign: "center",
                marginTop: "20%"
             }}   
            >
                Estados Screen
            </Text>
        </View>
    );
}

export default EstadosScreen;