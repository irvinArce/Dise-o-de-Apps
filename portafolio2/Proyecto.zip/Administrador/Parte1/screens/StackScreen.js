import React from "react";
import {View, Text, StyleSheet, TouchableOPacity} from "react-native";

const StackScreen = () => {
    return(
        <View>
            <Text
             style = {{
                fontSize: 30,
                textAlign: "center",
                marginTop: "20%"
             }}   
            >
                Stack Screen
            </Text>
        </View>
    );
}

export default StackScreen;