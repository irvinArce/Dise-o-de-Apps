import React from "react";
import {View, Text, StyleSheet, TouchableOPacity} from "react-native";

const CamEmplAct= () => {
    return(
        <View>
            <Text
             style = {{
                fontSize: 30,
                textAlign: "center",
                marginTop: "20%"
             }}   
            >
                Cambiar empleado de actividad
            </Text>
        </View>
    );
}

export default CamEmplAct;