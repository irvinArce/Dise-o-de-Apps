import React from "react";
import {View, Text, StyleSheet, TouchableOPacity} from "react-native";


const AsignarOR = () => {
    return(
        <View>
            <Text
             style = {{
                fontSize: 30,
                textAlign: "center",
                marginTop: "20%"
             }}   
            >
                Asginar Ordenes de trabajo
            </Text>
        </View>
    );
}

export default AsignarOR;