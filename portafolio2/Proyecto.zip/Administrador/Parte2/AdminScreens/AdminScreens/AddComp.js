import React from "react";
import {View, Text, StyleSheet, TouchableOPacity} from "react-native";

const AddComp= () => {
    return(
        <View>
            <Text
             style = {{
                fontSize: 30,
                textAlign: "center",
                marginTop: "20%"
             }}   
            >
                Agregar Componentes
            </Text>
        </View>
    );
}

export default AddComp;