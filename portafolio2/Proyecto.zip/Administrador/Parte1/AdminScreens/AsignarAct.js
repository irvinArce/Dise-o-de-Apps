import React from "react";
import {View, Text, StyleSheet, TouchableOPacity} from "react-native";

const AsignarAct = () => {
    return(
        <View>
            <Text
             style = {{
                fontSize: 30,
                textAlign: "center",
                marginTop: "20%"
             }}   
            >
                Asignar Actividades
            </Text>
        </View>
    );
}

export default AsignarAct;