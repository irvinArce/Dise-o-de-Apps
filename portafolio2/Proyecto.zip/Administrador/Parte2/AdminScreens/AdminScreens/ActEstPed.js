import React from "react";
import {View, Text, StyleSheet, TouchableOPacity} from "react-native";

const ActEstPed = () => {
    return(
        <View>
            <Text
             style = {{
                fontSize: 30,
                textAlign: "center",
                marginTop: "20%"
             }}   
            >
                Actualizar Etados de los pedidos
            </Text>
        </View>
    );
}

export default ActEstPed;